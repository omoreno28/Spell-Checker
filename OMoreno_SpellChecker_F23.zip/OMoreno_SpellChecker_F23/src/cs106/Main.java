package cs106;

import static sbcc.Core.*;
import static java.lang.System.*;
import static org.apache.commons.lang3.StringUtils.*;
import static java.lang.Math.*;

public class Main {

    public static void main(String[] args) {

    }

}
